
const express = require("express");
const router = express.Router();
const db = require("../config/db");

router.post("/login",(req,res)=>{

  const {username,password} = req.body;

  db.query(
    "SELECT * FROM users WHERE username=? AND password=?",
    [username,password],
    (err,result)=>{

      if(result.length > 0){

        res.json({
          success:true,
          role:result[0].role
        });

      }else{

        res.json({
          success:false,
          message:"Invalid Login"
        });

      }

    }
  );

});

module.exports = router;
