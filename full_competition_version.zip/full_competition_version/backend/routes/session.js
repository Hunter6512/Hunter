const express = require("express");

const router = express.Router();

const db = require("../config/db");

router.get("/status",(req,res)=>{

    db.query(
        "SELECT * FROM session_control LIMIT 1",
        (err,result)=>{

            if(err){

                return res.status(500).json({
                    success:false
                });

            }

            res.json(result[0]);

        }
    );

});

router.put("/open",(req,res)=>{

    db.query(
        "UPDATE session_control SET status='open' WHERE id=1",
        (err)=>{

            if(err){

                return res.status(500).json({
                    success:false
                });

            }

            res.json({
                success:true
            });

        }
    );

});

router.put("/close",(req,res)=>{

    db.query(
        "UPDATE session_control SET status='closed' WHERE id=1",
        (err)=>{

            if(err){

                return res.status(500).json({
                    success:false
                });

            }

            res.json({
                success:true
            });

        }
    );

});

module.exports = router;