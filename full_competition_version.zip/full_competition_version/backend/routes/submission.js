const express = require("express");

const router = express.Router();

const db = require("../config/db");

/* =========================
   GET SUBMISSION
========================= */

router.get("/",(req,res)=>{

    db.query(

        `SELECT *,

        (
            frontend_score +
            backend_score +
            ui_score +
            performance_score
        ) AS total_score

        FROM submissions

        ORDER BY total_score DESC`,

        (err,result)=>{

            if(err){

                console.log(err);

                return res.status(500).json(err);

            }

            res.json(result);

        }

    );

});

/* =========================
   SUBMIT PROJECT
========================= */

router.post("/",(req,res)=>{

    const {

        frontend_url,

        backend_url

    } = req.body;

    db.query(

        `INSERT INTO submissions(

            frontend_url,
            backend_url,
            status

        )

        VALUES(?,?,?)`,

        [

            frontend_url,
            backend_url,
            "SUBMITTED"

        ],

        (err)=>{

            if(err){

                console.log(err);

                return res.status(500).json(err);

            }

            res.json({

                success:true

            });

        }

    );

});

/* =========================
   UPDATE SCORE
========================= */

router.put("/score/:id",(req,res)=>{

    const frontend_score =
    Number(req.body.frontend_score);

    const backend_score =
    Number(req.body.backend_score);

    const ui_score =
    Number(req.body.ui_score);

    const performance_score =
    Number(req.body.performance_score);

    const id =
    Number(req.params.id);

    db.query(

        `UPDATE submissions

        SET

        frontend_score=?,
        backend_score=?,
        ui_score=?,
        performance_score=?

        WHERE id=?`,

        [

            frontend_score,
            backend_score,
            ui_score,
            performance_score,
            id

        ],

        (err,result)=>{

            if(err){

                console.log(err);

                return res.status(500).json(err);

            }

            res.json({

                success:true,
                result

            });

        }

    );

});

module.exports = router;