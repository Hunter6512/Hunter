const DEFAULT_DURATION = 3 * 60 * 60;

let duration = DEFAULT_DURATION;

let timerStarted = false;

let sessionState = "closed";

/* =========================
   LIVE CLOCK
========================= */

function updateClock(){

    const now = new Date();

    const date =
        now.toLocaleDateString(
            "en-US",
            {
                weekday:"short",
                year:"numeric",
                month:"short",
                day:"numeric"
            }
        );

    const time =
        now.toLocaleTimeString(
            "en-GB",
            {
                hour:"2-digit",
                minute:"2-digit",
                second:"2-digit"
            }
        );

    document.getElementById(
        "clock"
    ).innerHTML = `
    
        ${date}
        •
        ${time}

    `;

}

setInterval(updateClock,1000);

updateClock();

/* =========================
   COUNTDOWN
========================= */

function renderTimer(){

    let hours =
        Math.floor(duration / 3600);

    let minutes =
        Math.floor((duration % 3600) / 60);

    let seconds =
        duration % 60;

    document.getElementById(
        "timer"
    ).innerText =

        `${String(hours).padStart(2,"0")}:` +

        `${String(minutes).padStart(2,"0")}:` +

        `${String(seconds).padStart(2,"0")}`;

}

renderTimer();

setInterval(()=>{

    if(
        timerStarted &&
        duration > 0
    ){

        duration--;

        renderTimer();

    }

},1000);

/* =========================
   SESSION STATUS
========================= */

async function loadStatus(){

    try{

        const res = await fetch(
            "http://localhost:3000/api/session/status"
        );

        const data = await res.json();

        const statusText =
            document.getElementById(
                "sessionStatus"
            );

        /* OPEN */

        if(data.status === "open"){

            statusText.innerText =
            "LIVE";

            statusText.className =
            "status-open";

            if(sessionState !== "open"){

                duration =
                DEFAULT_DURATION;

                renderTimer();

            }

            timerStarted = true;

            sessionState = "open";

        }

        /* CLOSED */

        else{

            statusText.innerText =
            "CLOSED";

            statusText.className =
            "status-closed";

            timerStarted = false;

            duration =
            DEFAULT_DURATION;

            renderTimer();

            sessionState = "closed";

        }

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   OPEN SESSION
========================= */

async function openSession(){

    try{

        await fetch(
            "http://localhost:3000/api/session/open",
            {
                method:"PUT"
            }
        );

        loadStatus();

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   CLOSE SESSION
========================= */

async function closeSession(){

    try{

        await fetch(
            "http://localhost:3000/api/session/close",
            {
                method:"PUT"
            }
        );

        loadStatus();

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   LOAD SUBMISSIONS
========================= */

async function loadSubmissions(){

    try{

        const res = await fetch(
            "http://localhost:3000/api/submission"
        );

        const data = await res.json();

        const table =
            document.getElementById(
                "submissionTable"
            );

        table.innerHTML = "";

        data.forEach((item)=>{

            table.innerHTML += `
            
            <tr>

                <td>
                    #${item.id}
                </td>

                <td>
                    ${item.frontend_url}
                </td>

                <td>

                    <span class="status pending">

                        ${item.status}

                    </span>

                </td>

                <td>

                    <button
                        onclick="recheck(${item.id})"
                    >

                        Re-check

                    </button>

                </td>

            </tr>

            `;

        });

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   RECHECK
========================= */

async function recheck(id){

    try{

        await fetch(
            `http://localhost:3000/api/submission/${id}/recheck`,
            {
                method:"POST"
            }
        );

        loadSubmissions();

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   INITIALIZE
========================= */

loadStatus();

loadSubmissions();

setInterval(()=>{

    loadStatus();

    loadSubmissions();

},3000);