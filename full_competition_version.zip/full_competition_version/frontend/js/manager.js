/* =========================
   SECTION SWITCH
========================= */

function showSection(sectionId){

    document.getElementById(
        "dashboardSection"
    ).style.display = "none";

    document.getElementById(
        "scoreSection"
    ).style.display = "none";

    document.getElementById(
        "rankingSection"
    ).style.display = "none";

    document.getElementById(
        sectionId
    ).style.display = "block";

}

/* =========================
   LOAD DATA
========================= */

async function loadData(){

    try{

        const res = await fetch(
            "http://localhost:3000/api/submission"
        );

        const data = await res.json();

        renderDashboard(data);

        renderScores(data);

        renderRanking(data);

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   DASHBOARD
========================= */

function renderDashboard(data){

    document.getElementById(
        "totalCandidates"
    ).innerText = data.length;

    const pass =
        data.filter(
            item =>
            (item.total_score || 0) >= 70
        ).length;

    const fail =
        data.filter(
            item =>
            (item.total_score || 0) < 70
        ).length;

    document.getElementById(
        "passCount"
    ).innerText = pass;

    document.getElementById(
        "failCount"
    ).innerText = fail;

}

/* =========================
   SCORE PANEL
========================= */

function renderScores(data){

    const container =
        document.getElementById(
            "scoreTable"
        );

    container.innerHTML = "";

    data.forEach((team)=>{

        container.innerHTML += `

        <div class="score-card">

            <div class="score-top">

                <div>

                    <h2>
                        Team #${team.id}
                    </h2>

                    <p class="project-link">
                        ${team.frontend_url || "-"}
                    </p>

                </div>

                <span class="rank-badge">

                    ${
                        team.total_score || 0
                    } pts

                </span>

            </div>

            <!-- FRONTEND -->

            <div class="score-item">

                <div class="score-header">

                    <label
                        for="frontend-${team.id}"
                    >
                        Frontend
                    </label>

                    <span
                        id="frontend-value-${team.id}"
                    >
                        ${
                            team.frontend_score || 0
                        }
                    </span>

                </div>

                <input
                    type="range"

                    min="0"

                    max="25"

                    value="${
                        team.frontend_score || 0
                    }"

                    id="frontend-${team.id}"

                    oninput="
                    document.getElementById(
                    'frontend-value-${team.id}'
                    ).innerText=this.value
                    "
                >

            </div>

            <!-- BACKEND -->

            <div class="score-item">

                <div class="score-header">

                    <label
                        for="backend-${team.id}"
                    >
                        Backend
                    </label>

                    <span
                        id="backend-value-${team.id}"
                    >
                        ${
                            team.backend_score || 0
                        }
                    </span>

                </div>

                <input
                    type="range"

                    min="0"

                    max="25"

                    value="${
                        team.backend_score || 0
                    }"

                    id="backend-${team.id}"

                    oninput="
                    document.getElementById(
                    'backend-value-${team.id}'
                    ).innerText=this.value
                    "
                >

            </div>

            <!-- UI -->

            <div class="score-item">

                <div class="score-header">

                    <label
                        for="ui-${team.id}"
                    >
                        UI / UX
                    </label>

                    <span
                        id="ui-value-${team.id}"
                    >
                        ${
                            team.ui_score || 0
                        }
                    </span>

                </div>

                <input
                    type="range"

                    min="0"

                    max="25"

                    value="${
                        team.ui_score || 0
                    }"

                    id="ui-${team.id}"

                    oninput="
                    document.getElementById(
                    'ui-value-${team.id}'
                    ).innerText=this.value
                    "
                >

            </div>

            <!-- PERFORMANCE -->

            <div class="score-item">

                <div class="score-header">

                    <label
                        for="performance-${team.id}"
                    >
                        Performance
                    </label>

                    <span
                        id="performance-value-${team.id}"
                    >
                        ${
                            team.performance_score || 0
                        }
                    </span>

                </div>

                <input
                    type="range"

                    min="0"

                    max="25"

                    value="${
                        team.performance_score || 0
                    }"

                    id="performance-${team.id}"

                    oninput="
                    document.getElementById(
                    'performance-value-${team.id}'
                    ).innerText=this.value
                    "
                >

            </div>

            <button
                onclick="saveScore(${team.id})"
            >
                Save Score
            </button>

        </div>

        `;

    });

}

/* =========================
   SAVE SCORE
========================= */

async function saveScore(id){

    const frontend_score =
        document.getElementById(
            `frontend-${id}`
        ).value;

    const backend_score =
        document.getElementById(
            `backend-${id}`
        ).value;

    const ui_score =
        document.getElementById(
            `ui-${id}`
        ).value;

    const performance_score =
        document.getElementById(
            `performance-${id}`
        ).value;

    try{

        await fetch(

            `http://localhost:3000/api/submission/score/${id}`,

            {

                method:"PUT",

                headers:{
                    "Content-Type":"application/json"
                },

                body:JSON.stringify({

                    frontend_score,

                    backend_score,

                    ui_score,

                    performance_score

                })

            }

        );

        alert(
            "Saved Successfully"
        );

        loadData();

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   RANKING
========================= */

function renderRanking(data){

    const ranking =
        [...data].sort(

            (a,b)=>

            (b.total_score || 0)

            -

            (a.total_score || 0)

        );

    const table =
        document.getElementById(
            "rankingTable"
        );

    table.innerHTML = "";

    ranking.forEach((team,index)=>{

        table.innerHTML += `

        <tr>

            <td>
                #${index + 1}
            </td>

            <td>
                Team ${team.id}
            </td>

            <td>
                ${team.total_score || 0}
            </td>

        </tr>

        `;

    });

}

/* =========================
   INIT
========================= */

loadData();