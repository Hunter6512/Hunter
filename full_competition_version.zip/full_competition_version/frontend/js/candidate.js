/* =========================
   SECTION
========================= */

function showSection(sectionId){

    document.getElementById(
        "dashboardSection"
    ).style.display = "none";

    document.getElementById(
        "submitSection"
    ).style.display = "none";

    document.getElementById(
        "rankingSection"
    ).style.display = "none";

    document.getElementById(
        sectionId
    ).style.display = "block";

}

/* =========================
   LOAD SESSION
========================= */

async function loadSession(){

    try{

        const res = await fetch(
            "http://localhost:3000/api/session/status"
        );

        const data = await res.json();

        document.getElementById(
            "sessionStatus"
        ).innerText =
        data.status.toUpperCase();

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   CLOCK
========================= */

function updateClock(){

    const now = new Date();

    document.getElementById(
        "clock"
    ).innerText =
    now.toLocaleString();

}

setInterval(updateClock,1000);

updateClock();

/* =========================
   SUBMIT
========================= */

async function submitProject(){

    const frontend_url =
        document.getElementById(
            "frontendUrl"
        ).value;

    const backend_url =
        document.getElementById(
            "backendUrl"
        ).value;

    try{

        await fetch(

            "http://localhost:3000/api/submission",

            {

                method:"POST",

                headers:{
                    "Content-Type":"application/json"
                },

                body:JSON.stringify({

                    frontend_url,

                    backend_url

                })

            }

        );

        alert(
            "Project Submitted"
        );

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   RANKING
========================= */

async function loadRanking(){

    try{

        const res = await fetch(
            "http://localhost:3000/api/submission"
        );

        const data = await res.json();

        const ranking =
            [...data].sort(

                (a,b)=>

                (b.total_score || 0)

                -

                (a.total_score || 0)

            );

        const table =
            document.getElementById(
                "rankingTable"
            );

        table.innerHTML = "";

        ranking.forEach((team,index)=>{

            table.innerHTML += `

            <tr>

                <td>
                    #${index + 1}
                </td>

                <td>
                    Team ${team.id}
                </td>

                <td>
                    ${team.total_score || 0}
                </td>

            </tr>

            `;

        });

    }

    catch(err){

        console.log(err);

    }

}

/* =========================
   TIMER
========================= */

function startTimer(){

    let hours = 3;
    let minutes = 0;
    let seconds = 0;

    setInterval(()=>{

        if(seconds === 0){

            if(minutes === 0){

                if(hours === 0){

                    return;

                }

                hours--;
                minutes = 59;
                seconds = 59;

            }

            else{

                minutes--;
                seconds = 59;

            }

        }

        else{

            seconds--;

        }

        document.getElementById(
            "timer"
        ).innerText =

        `${String(hours).padStart(2,"0")}:${String(minutes).padStart(2,"0")}:${String(seconds).padStart(2,"0")}`;

    },1000);

}

/* =========================
   INIT
========================= */

loadSession();

loadRanking();

startTimer();